SELECT * FROM program_single_view LIMIT 10;
-- # repeater and onetimer

SELECT CASE WHEN recency BETWEEN 30 AND 90 AND availablepoints <= 25 AND `total visits`>=3 AND atv<=250 
THEN 'Repeaters who have recency between 30-90 days, points available <=25, and have frequency >=3, atv <=250'
WHEN recency BETWEEN 30 AND 90 AND availablepoints <= 25 AND `total visits`>=3 AND atv>250 AND atv <=500 
THEN 'Repeaters who have recency between 30-90 days, points available <=25, and have frequency >=3, atv between 250 and 500'
WHEN recency BETWEEN 30 AND 90 AND availablepoints <= 25 AND `total visits`>=3 AND atv>500 AND atv<=750 
THEN 'Repeaters who have recency between 30-90 days, points available <=25, and have frequency >=3, atv between 500 and 750'
WHEN recency BETWEEN 30 AND 90 AND availablepoints >25 AND availablepoints <=100 
THEN 'Repeaters who have recency between 30-90 days, points available 26-100'
WHEN recency BETWEEN 91 AND 180 AND availablepoints <=25 AND `total visits`>=3 AND atv>=250 
THEN 'Repeaters who have recency between 91 and 180 days and points <=25, and frequency >= 3, atv >=250'
WHEN recency BETWEEN 91 AND 180 AND availablepoints >25 AND availablepoints <=100 AND `total visits`>=3 AND atv>=250 
THEN 'Repeaters who have recency between 91 and 180 days and points between 25 -100, and frequency >= 3, atv >=250'
WHEN recency BETWEEN 30 AND 254 AND `total visits`=2 AND atv>=250 AND atv<=750 
THEN 'Repeaters with recency between 30 and 254 days and frequency = 2, atv between 250 & 750' 
WHEN recency BETWEEN 30 AND 90 AND atv>250 AND atv<=500 AND `total visits` = 1 
THEN 'Onetimers who have atv between 250-500 and have recency between 30-90'
WHEN recency BETWEEN 30 AND 90 AND atv>500 AND atv<=750 AND `total visits` = 1 
THEN 'Onetimers who have atv between 501-750 and have recency between 30-90'
WHEN recency BETWEEN 30 AND 90 AND atv >750 AND atv<=1000 AND `total visits` = 1  
THEN 'Onetimers who have atv between 751-1000 and have recency between 30-90'
WHEN recency BETWEEN 30 AND 90 AND atv>1000 AND `total visits` = 1 
THEN 'Onetimers who have atv >1000 and recency between 30 and 90'
WHEN recency >=254 AND atv>=300 THEN 'Customers who have recency >=254 days, atv >=300'
END 'segments',COUNT(DISTINCT mobile)customer,SUM(`total spends`)sales,SUM(`total transactions`)bills 
FROM (
SELECT mobile,recency,availablepoints,`total spends`,
`total visits`,SUM(`total spends`)/SUM(`total transactions`)atv,
`total transactions` FROM program_single_view
GROUP BY 1)a
GROUP BY 1;

-- for atv >=300

SELECT CASE WHEN recency >=254 AND atv>=300 THEN 'Customers who have recency >=254 days, atv >=300' END 'segment',
COUNT(DISTINCT mobile)customer,
SUM(`total spends`),SUM(`total transactions`) FROM(
SELECT mobile,recency,availablepoints,`total spends`,
`total visits`,SUM(`total spends`)/SUM(`total transactions`)atv,
`total transactions` FROM program_single_view
GROUP BY 1)a
GROUP BY 1;

-- QC 
SELECT COUNT(DISTINCT mobile)customer,SUM(`total spends`)sales,SUM(`total transactions`)bill FROM (
SELECT mobile,recency,availablepoints,`total spends`,
`total visits`,SUM(`total spends`)/SUM(`total transactions`)atv,
`total transactions` FROM program_single_view
GROUP BY 1)a
WHERE recency BETWEEN 30 AND 90 AND availablepoints<=25 AND `total visits`>=3 AND atv>500 AND atv<=750;


SELECT COUNT(DISTINCT mobile)customr,SUM(sales)sales,SUM(bills)bills FROM(
SELECT mobile,DATEDIFF(CURDATE(),MAX(txndate))recency,SUM(amount)sales,MAX(frequencycount)fc,
COUNT(DISTINCT uniquebillno)bills,b.availablepoints ,SUM(amount)/COUNT(DISTINCT uniquebillno)atv 
FROM txn_report_accrual_redemption a LEFT JOIN member_report b USING(mobile)
WHERE storecode NOT LIKE 'demo' AND billno NOT LIKE '%test%' AND billno NOT LIKE '%role%'
GROUP BY 1)a
WHERE recency >=254 AND atv>=300 ;

-- QC end

#mom trends on weekdays
SELECT YEAR(txndate)txnyear,MONTHNAME(txndate)txnmonth,DAYNAME(txndate)day_of_week,COUNT(DISTINCT mobile)customer,SUM(amount)sales,COUNT(DISTINCT uniquebillno)bills 
FROM txn_report_accrual_redemption 
WHERE txndate BETWEEN '2024-05-01' AND '2025-03-31' AND billno NOT LIKE '%test%' AND billno NOT LIKE '%role%' AND storecode NOT LIKE 'demo'
GROUP BY 1,2,3
ORDER BY txnyear,txnmonth,FIELD(day_of_week, 
    'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday');
    
    
--     email available 
    
SELECT COUNT(DISTINCT mobile) FROM program_single_view
WHERE email IS NOT NULL;

SELECT COUNT(DISTINCT mobile) FROM member_report 
WHERE email IS NOT NULL;